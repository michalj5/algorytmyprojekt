#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <numeric>
#include <chrono>
#include <limits.h>
#include <vector>

using namespace std;
using namespace std::chrono;

high_resolution_clock::time_point stop;
high_resolution_clock::time_point start;
chrono::duration<double> czas;

void generujciag(int *tab, int roz)   // generujemy pseudolosowa tablice zer i jedynek
{
    srand(time(NULL));
    for(int i = 0; i < roz; i++)
    {
       tab[i] = rand()%2;
    }
}
void wynik(vector<int> &podciag, vector<int> &podciag2, int *tab, int roz)
{
    int x, y, indeks = 0, indeks2 = 0, suma = 0, suma2 = 0;
    for(int i = 0; i < roz; i++)
    {
     if(tab[i]==0)
     {
        tab[i]--;               // jesli element tablicy jest zerem zamieniamy go na -1
     }
     suma = suma + tab[i];      // sumujemy kolejne elementy ciagu
     if(suma == 0)
     {
        x = i;                  // szukamy najwiekszego indeksu dla ktorego suma elementow ciagu wynosi 0
        if(i>indeks)
        {
            indeks = i;
        }
     }
    }
    suma = 0;

    for(int j = roz -1 ; j >= 0; j--)     // iterujemy od elementu o 1 mniejszego niz rozmiar tablicy ( max indeks tablicy 100 elementowej to 99)
    {
        if(tab[j]==0)
        {
            tab[j]--;                    // jesli element tablicy jest zerem zamieniamy go na -1
        }
        suma2 = suma2 + tab[j];          //sumujemy kolejne elementy ciagu
        if(suma2==0)
        {
            y = j;
            if(j>indeks2)
            {
                indeks2 = y;             //  szukamy najmniejszego indeksu dla ktorego suma elementow ciagu wynosi 0
            }
        }
    }
    suma2 = 0;

    for(int k = 0; k <= indeks; k++)   // wpisujemy podciag do wektora od piewszego elementu do indeksu
        {
            if(tab[k]==-1)
            {
                tab[k]++;                    //jesli element to -1 to zamieniamy go na 0
            }
            podciag.push_back(tab[k]);
        }
    for(int k = roz - 1; k >= indeks2; k--)
        {
            if(tab[k]==-1)
            {
                tab[k]++;
            }
            podciag2.push_back(tab[k]);
        }
}

void zapis(vector<int> &podciag, vector<int> &podciag2)
{
    ofstream zapis("podciag.txt");
    if(zapis)                                                                // jesli plik zostanie utworzony to wykonujemy dalsze czynnosci
    {
        if(podciag.size() > podciag2.size())
        {
            zapis<< "ilosc elementow podciagu: "<<podciag.size()<<endl;
            for(int i = 0; i < podciag.size(); i++)
            {
                zapis << podciag[i] << ", ";                                // zapisujemy do plik elementu wektora
            }
        }
        else if(podciag2.size() > podciag.size())
        {
            zapis<< "ilosc elementow podciagu: "<<podciag2.size()<<endl;
            for(int i = 0; i < podciag2.size(); i++)
            {
                zapis << podciag2[i] << ", ";
            }
        }
    }
}


int main()
{
    vector<int> podciag;
    vector<int> podciag2;

    int ile_elem,  *tab;

    cout<<"Podaj rozmiar tablicy"<<endl;
    cin>>ile_elem;

    tab = new int [ile_elem];

    //cout<<"wygenerowany ciag: "<<endl;
    generujciag(tab, ile_elem);                          // wywolanie funckji generujacej ciag

    /*for(int a = 0; a < ile_elem; a++)
    {                                                    // zakomentowane instrukcje wyswietlaja elemntu wygenerowanego ciagu
        cout<<tab[a]<<", ";
    } */
    start = high_resolution_clock::now();
    wynik(podciag, podciag2, tab, ile_elem);             // wywolanie funckji wykonujacej algorytm
    stop = high_resolution_clock::now();

    czas = stop-start;                                   // obliczenie czasu wykonania algorytmu

    cout << endl << "Czas wykonania algorytmu: "<<setprecision(5)<<czas.count()<<"s\n";

    zapis(podciag, podciag2);                            // wywolanie funckji zapisujacej do pliku

    delete [] tab;

   return 0;
}
